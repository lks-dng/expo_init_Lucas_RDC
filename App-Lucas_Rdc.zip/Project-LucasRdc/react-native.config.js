module.exports = {
    project: {
        ios:{},
        android:{}
    },
    assets:['./assets/fonts/Menlo-Regular.woff'],
    assets:['./assets/fonts/Monaco.woff']
}