import { StyleSheet } from "react-native";

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#0a234e',
      
    },
    inputContainer: {
      marginTop: 63,
      marginHorizontal: 20,
      flexDirection: 'row',
      fontFamily: 'Menlo',
      justifyContent: 'space-between'
    },
  
    input: {
      width: '85%',
      paddingLeft: 10,
      paddingRight: 10,
      borderColor: '#ffffff',
      borderWidth: 1.5,
      height: 40, 
      color: '#ffffff',
      fontFamily: 'Menlo', 
      marginRight: 10,
    },
  
    listContainer: {
      marginHorizontal: 20,
      marginTop: 15,
    },
  
    itemList: {
      width: '85%',
      paddingTop: 10,
      paddingLeft: 10,
      paddingRight: 10,
      borderColor: '#bed7a4',
      borderWidth: 1.5,
      height: 40, 
      color: '#bed7a4',
      fontSize: 14,
      fontFamily: 'Menlo',  
      fontWeight: 'bold',
      marginBottom: 10,
  
    },
  
    button: {
      color: '#bed7a4',
      fontWeight: 'bold',
      borderColor: '#bed7a4',
      borderWidth: 1.5,
      paddingHorizontal: 10,
      paddingVertical: 10,
  
    },
  
    modaleContainer: {
      backgroundColor: '#0a234e',
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 50,
      paddingVertical: 20,
    },
    modalTitle: {
      fontFamily: 'Menlo',
      fontSize: 14,
      fontWeight: 'bold',
      marginBottom: 10,
      color: '#ffffff'
    },
    ModalDetailContainer: {
      paddingVertical: 20,
    },
    modalDetailMessage: {
      fontFamily: 'Menlo',
      fontSize: 16,
      color: '#bed7a4'
  
    },
    selectedTask: {
      fontSize: 12,
      fontFamily: 'Menlo',
      color: '#bed7a4',
      fontWeight: 'bold',
      paddingVertical: 10,
      textAlign: 'center',
    },
    modalButtonContainer: {
      width: '75%',
      flexDirection: 'row',
      justifyContent: 'space-around',
      marginHorizontal: 20,
    },
  
  })
  
  // #0a234e Azul Oscuro
  // #12326a Azul Claro
  // #ffffff Blanco
  // #f1a2a6 Rosa Claro
  // #bed7a4 Verde Manzana
  // #f6c797 Color Crema
  
