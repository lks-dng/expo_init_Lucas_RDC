import { Button, FlatList, Modal, Text, TextInput, Touchable, TouchableOpacity, View } from 'react-native';
import React, { useState } from 'react';

import { styles } from './Styles';

const App = () =>  {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);

  const onHandlerChange = (text) => {
    setTask(text)
  }

  const onHandlerSubmit = () => {
    setTasks([
      ... tasks,
      {
        id: Math.random().toString(), 
        value: task,
      }
    ]);
    setTask('');
  }

  const onHandlerModal = (item) => {
    setIsModalVisible(!isModalVisible); 
    setSelectedTask(item);
  }

  const renderItem = ({ item }) => (
    <TouchableOpacity style={styles.itemContainer} onPress={() => onHandlerModal(item)}>
      <Text style={styles.itemList}>{item.value}</Text>
    </TouchableOpacity>
  )

  const keyEstractor = (item) => item.id;


  const onHandleCancel = () => {
    setIsModalVisible(!isModalVisible);
    setSelectedTask(null);
  }


  const onHandleDelete = (id) => {
    setTasks((prevTaskList) => prevTaskList.filter((task) => task.id !== selectedTask.id))
    setIsModalVisible(!isModalVisible);

  }




  
  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput 
          style={styles.input} 
          placeholder='Add a new task' 
          placeholderTextColor="#d6d5cb"
          autoComplete='off'
          autoCorrect={false}
          autoCapitalize='none'
          value={task}
          onChangeText={onHandlerChange}
        />
        <Button disabled={!task} title='Add' onPress={onHandlerSubmit} color='#bed7a4'/>
      </View>
      <FlatList
        data={tasks}
        renderItem={renderItem}
        keyEstractor={keyEstractor}
        style={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
      <Modal visible={isModalVisible} animationType='slide'>
        <View style={styles.modaleContainer}>
            <Text style={styles.modalTitle}>Task Detail</Text>
            <View style={styles.ModalDetailContainer}>
              <Text style={styles.modalDetailMessage}>Are you sure to delete this task?</Text>
              <Text style={styles.selectedTask}>{selectedTask?.value}</Text>
            </View>
            <View style={styles.modalButtonContainer}>
              <Button
                title='Back'
                color='#bed7a4'
                onPress={onHandleCancel}
              />
              <Button
                title='Delete'
                color='#f1a2a6'
                onPress={onHandleDelete}
              />
            </View>
        </View>
      </Modal>
    </View>
  );
}

// #0a234e Azul Oscuro
// #12326a Azul Claro
// #ffffff Blanco
// #f1a2a6 Rosa Claro
// #bed7a4 Verde Manzana
// #f6c797 Color Crema

export default App;