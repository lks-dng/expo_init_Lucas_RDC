import App from './src/Index';
import { registerRootComponent } from "expo";

registerRootComponent(App);
